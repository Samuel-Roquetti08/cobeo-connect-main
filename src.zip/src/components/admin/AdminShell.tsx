import { Link, useNavigate, useRouterState } from "@tanstack/react-router";
import {
  LayoutDashboard, Users, FileText, Tag, Download, Settings, LogOut, Bell, Menu, X,
} from "lucide-react";
import { useEffect, useState, type ReactNode } from "react";
import { useAdminAuth } from "@/lib/adminAuth";
import { Toaster } from "@/components/ui/sonner";

const NAV_GESTAO = [
  { to: "/admin/dashboard", label: "Dashboard", icon: LayoutDashboard },
  { to: "/admin/inscritos", label: "Inscritos no Evento", icon: Users },
  { to: "/admin/trabalhos", label: "Trabalhos Submetidos", icon: FileText },
  { to: "/admin/cupons", label: "Cupons", icon: Tag },
  { to: "/admin/exportar", label: "Exportar Dados", icon: Download },
];

const PAGE_TITLES: Record<string, string> = {
  "/admin/dashboard": "Dashboard",
  "/admin/inscritos": "Inscritos no Evento",
  "/admin/trabalhos": "Trabalhos Submetidos",
  "/admin/cupons": "Cupons",
  "/admin/exportar": "Exportar Dados",
  "/admin/configuracoes": "Configurações",
};

export function AdminShell({ children }: { children: ReactNode }) {
  const navigate = useNavigate();
  const { user, ready, logout } = useAdminAuth();
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const [mobileOpen, setMobileOpen] = useState(false);

  useEffect(() => {
    if (ready && !user) navigate({ to: "/admin/login" });
  }, [ready, user, navigate]);

  useEffect(() => { setMobileOpen(false); }, [pathname]);

  if (!ready || !user) {
    return <div className="min-h-screen bg-[#f9f6f4]" />;
  }

  const title = PAGE_TITLES[pathname] ?? "Admin";
  const today = new Date().toLocaleDateString("pt-BR", {
    day: "2-digit", month: "long", year: "numeric",
  });

  return (
    <div className="min-h-screen bg-[#f9f6f4]" style={{ fontFamily: "Poppins, system-ui, sans-serif" }}>
      <Toaster position="top-right" />

      {/* Mobile toggle */}
      <button
        onClick={() => setMobileOpen((o) => !o)}
        className="fixed top-3 left-3 z-50 rounded-md bg-[#1a0505] p-2 text-white shadow-lg md:hidden"
        aria-label="Menu"
      >
        {mobileOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
      </button>

      {/* Sidebar */}
      <aside
        className={`fixed inset-y-0 left-0 z-40 flex w-60 flex-col bg-[#1a0505] text-white/75 transition-transform md:translate-x-0 ${
          mobileOpen ? "translate-x-0" : "-translate-x-full"
        }`}
      >
        <div className="flex items-center gap-3 px-5 py-5">
          <div className="grid h-10 w-10 place-items-center rounded-md bg-[#731111] font-bold text-white">
            II
          </div>
          <div>
            <div className="text-[10px] uppercase tracking-[0.1em] text-white/40">II COBEO</div>
            <div className="text-sm font-semibold text-white" style={{ fontWeight: 600 }}>
              Admin
            </div>
          </div>
        </div>

        <div className="h-px bg-white/10" />

        <nav className="flex-1 overflow-y-auto px-3 py-5">
          <div className="px-3 pb-2 text-[10px] font-semibold uppercase tracking-[0.1em] text-white/40">
            Gestão
          </div>
          <ul className="space-y-1">
            {NAV_GESTAO.map((item) => {
              const active = pathname.startsWith(item.to);
              const Icon = item.icon;
              return (
                <li key={item.to}>
                  <Link
                    to={item.to}
                    className={`relative flex items-center gap-3 rounded-md px-3 py-2 text-[13px] transition-colors ${
                      active
                        ? "bg-[#731111] text-white"
                        : "text-white/75 hover:bg-white/[0.06] hover:text-white"
                    }`}
                  >
                    {active && (
                      <span className="absolute inset-y-1.5 left-0 w-[3px] rounded-r bg-[#C9A84C]" />
                    )}
                    <Icon className="h-4 w-4 shrink-0" />
                    <span>{item.label}</span>
                  </Link>
                </li>
              );
            })}
          </ul>

          <div className="mt-6 px-3 pb-2 text-[10px] font-semibold uppercase tracking-[0.1em] text-white/40">
            Sistema
          </div>
          <ul className="space-y-1">
            <li>
              <Link
                to="/admin/configuracoes"
                className={`flex items-center gap-3 rounded-md px-3 py-2 text-[13px] transition-colors ${
                  pathname.startsWith("/admin/configuracoes")
                    ? "bg-[#731111] text-white"
                    : "text-white/75 hover:bg-white/[0.06] hover:text-white"
                }`}
              >
                <Settings className="h-4 w-4" />
                <span>Configurações</span>
              </Link>
            </li>
            <li>
              <button
                onClick={() => { logout(); navigate({ to: "/admin/login" }); }}
                className="flex w-full items-center gap-3 rounded-md px-3 py-2 text-[13px] text-white/75 transition-colors hover:bg-white/[0.06] hover:text-white"
              >
                <LogOut className="h-4 w-4" />
                <span>Sair</span>
              </button>
            </li>
          </ul>
        </nav>

        <div className="border-t border-white/10 p-4">
          <div className="flex items-center gap-3">
            <div className="grid h-9 w-9 place-items-center rounded-full bg-[#C9A84C] text-xs font-bold text-[#1a0505]">
              {user.initials}
            </div>
            <div className="min-w-0">
              <div className="truncate text-[12px] font-medium text-white">{user.email}</div>
              <div className="text-[10px] text-white/50">{user.role}</div>
            </div>
          </div>
        </div>
      </aside>

      {/* Main */}
      <div className="md:pl-60">
        <header className="sticky top-0 z-30 flex h-16 items-center justify-between border-b border-[#d9d9d9] bg-white px-6">
          <h1 className="pl-8 text-[20px] font-semibold text-[#1a1a1a] md:pl-0" style={{ fontWeight: 600 }}>
            {title}
          </h1>
          <div className="flex items-center gap-5">
            <button className="relative text-[#6b6b6b] hover:text-[#1a1a1a]" aria-label="Notificações">
              <Bell className="h-5 w-5" />
              <span className="absolute -right-1 -top-1 h-2 w-2 rounded-full bg-[#731111]" />
            </button>
            <span className="hidden text-xs text-[#6b6b6b] md:inline">{today}</span>
            <div className="grid h-8 w-8 place-items-center rounded-full bg-[#731111] text-[11px] font-bold text-white">
              {user.initials}
            </div>
          </div>
        </header>
        <main className="p-6 lg:p-8">{children}</main>
      </div>
    </div>
  );
}
