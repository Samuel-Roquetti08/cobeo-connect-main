import { motion, type Variants } from "framer-motion";
import { Calendar, MapPin } from "lucide-react";
import { COBEO_ILLUSTRATION } from "./logos";
import { evento } from "@/data/event";

const item: Variants = {
  hidden: { opacity: 0, y: 24 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.7, ease: "easeOut" } },
};


export function Hero() {
  return (
    <section
      id="top"
      className="relative flex min-h-[100vh] items-center overflow-hidden text-white"
      style={{
        background:
          "radial-gradient(ellipse at 30% 50%, #8B1515 0%, #731111 60%, #4a0a0a 100%)",
      }}
    >
      {/* noise */}
      <div
        aria-hidden
        className="pointer-events-none absolute inset-0 opacity-[0.04] mix-blend-overlay"
        style={{
          backgroundImage:
            "url(\"data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='160' height='160'><filter id='n'><feTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='2'/></filter><rect width='100%' height='100%' filter='url(%23n)'/></svg>\")",
        }}
      />

      <div className="relative z-10 mx-auto grid w-full max-w-7xl grid-cols-1 items-center gap-12 px-4 py-28 sm:px-6 md:grid-cols-[55%_45%] md:py-32">
        <motion.div
          initial="hidden"
          animate="visible"
          transition={{ staggerChildren: 0.18, delayChildren: 0.05 }}
        >
          <motion.span
            variants={item}
            className="inline-block rounded-full border border-gold/70 px-4 py-1.5 font-body text-[11px] font-semibold uppercase tracking-[0.14em] text-gold"
          >
            {evento.edicao}
          </motion.span>

          <motion.h1
            variants={item}
            className="mt-6 font-display font-extrabold leading-[0.9] tracking-[-0.03em] text-white"
            style={{ fontSize: "clamp(64px, 10vw, 120px)" }}
          >
            II COBEO
          </motion.h1>

          <motion.p
            variants={item}
            className="mt-4 font-display font-semibold text-secondary"
            style={{ fontSize: "clamp(18px, 2.2vw, 28px)" }}
          >
            Congresso de Odontologia de Bebedouro
          </motion.p>

          <motion.span variants={item} className="my-6 block h-[2px] w-[60px] bg-gold" />

          <motion.div
            variants={item}
            className="flex flex-wrap items-center gap-x-6 gap-y-2 font-body text-[15px] text-white/80"
          >
            <span className="inline-flex items-center gap-2">
              <Calendar className="h-4 w-4 text-gold" /> {evento.data}
            </span>
            <span className="inline-flex items-center gap-2">
              <MapPin className="h-4 w-4 text-gold" /> {evento.local}
            </span>
          </motion.div>

          <motion.div variants={item} className="mt-10 flex flex-wrap items-center gap-4">
            <a
              href="#inscricoes"
              className="rounded-md bg-gold px-9 py-4 font-body text-sm font-semibold text-primary shadow-lg transition-all hover:-translate-y-0.5 hover:brightness-110"
            >
              Inscrever-se Agora
            </a>
            <a
              href="#programacao"
              className="rounded-md border-[1.5px] border-white/40 px-9 py-4 font-body text-sm font-semibold text-white transition-colors hover:bg-white/10"
            >
              Ver Programação
            </a>
          </motion.div>

          <motion.p
            variants={item}
            className="mt-5 font-body text-[13px] text-white/50"
          >
            Vagas Limitadas — Garanta sua inscrição
          </motion.p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, scale: 0.98 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 1, delay: 0.4 }}
          className="relative hidden md:block"
        >
          <motion.img
            src={COBEO_ILLUSTRATION}
            alt="Ilustração arquitetônica do prédio UNIFAFIBE"
            className="mx-auto w-full max-w-[520px]"
            style={{ mixBlendMode: "luminosity", opacity: 0.85 }}
            animate={{ y: [-8, 0, -8] }}
            transition={{ duration: 6, repeat: Infinity, ease: "easeInOut" }}
          />
        </motion.div>

        {/* mobile bg illustration */}
        <img
          src={COBEO_ILLUSTRATION}
          alt=""
          aria-hidden
          className="pointer-events-none absolute inset-0 -z-0 m-auto h-full w-full object-contain opacity-[0.08] md:hidden"
        />
      </div>
    </section>
  );
}
