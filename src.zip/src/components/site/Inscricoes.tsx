import { useEffect, useMemo, useState, type ChangeEvent, type DragEvent } from "react";
import { motion, AnimatePresence, type Variants } from "framer-motion";
import {
  Check,
  X,
  Loader2,
  CreditCard,
  QrCode,
  Banknote,
  Copy,
  Upload,
  FileText,
  ChevronDown,
  Plus,
  Info,
} from "lucide-react";
import { SectionTitle } from "./SectionTitle";
import { precos } from "@/data/event";

type Method = "pix" | "debito" | "credito";
type TabKey = "evento" | "trabalho";

const COUPONS: Record<string, number> = {
  COBEO10: 10,
  ALUNO20: 20,
};

const fade: Variants = {
  hidden: { opacity: 0, y: 12 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.35, ease: "easeOut" } },
  exit: { opacity: 0, y: -8, transition: { duration: 0.2 } },
};

export function Inscricoes() {
  const [tab, setTab] = useState<TabKey>("evento");

  return (
    <section id="inscricoes" className="bg-surface py-16 md:py-[120px]">
      <div className="mx-auto max-w-5xl px-4 sm:px-6">
        <SectionTitle label="Garanta sua vaga" title="Inscrições" align="center" />

        <div className="mt-12 grid grid-cols-1 gap-2 sm:grid-cols-2">
          <TabButton active={tab === "evento"} onClick={() => setTab("evento")}>
            Inscrição no Evento
          </TabButton>
          <TabButton active={tab === "trabalho"} onClick={() => setTab("trabalho")}>
            Submissão de Trabalho Acadêmico
          </TabButton>
        </div>

        <div className="rounded-b-xl rounded-tr-xl border border-border bg-surface p-6 sm:p-10">
          <AnimatePresence mode="wait">
            {tab === "evento" ? (
              <motion.div key="evento" variants={fade} initial="hidden" animate="visible" exit="exit">
                <FlowEvento onSwitchToTrabalho={() => setTab("trabalho")} />
              </motion.div>
            ) : (
              <motion.div key="trabalho" variants={fade} initial="hidden" animate="visible" exit="exit">
                <FlowTrabalho />
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </section>
  );
}

function TabButton({
  active,
  onClick,
  children,
}: {
  active: boolean;
  onClick: () => void;
  children: React.ReactNode;
}) {
  return (
    <button
      onClick={onClick}
      className={`rounded-t-lg px-6 py-4 text-left font-body text-sm font-semibold transition-colors ${
        active
          ? "bg-primary text-white"
          : "border border-border bg-background text-muted-foreground hover:text-foreground"
      }`}
    >
      {children}
    </button>
  );
}

/* ============== STEPPER ============== */
function Stepper({ steps, current }: { steps: string[]; current: number }) {
  return (
    <div className="mb-10 flex items-center justify-between gap-2">
      {steps.map((label, i) => {
        const done = i < current;
        const active = i === current;
        return (
          <div key={label} className="flex flex-1 items-center">
            <div className="flex flex-col items-center">
              <div
                className={`flex h-9 w-9 items-center justify-center rounded-full font-body text-sm font-semibold transition-colors ${
                  done
                    ? "bg-gold text-primary"
                    : active
                      ? "bg-primary text-white"
                      : "bg-border text-muted-foreground"
                }`}
              >
                {done ? <Check className="h-4 w-4" /> : i + 1}
              </div>
              <span className="mt-2 text-center font-body text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">
                {label}
              </span>
            </div>
            {i < steps.length - 1 && (
              <div
                className={`mx-2 mb-6 h-[2px] flex-1 ${done ? "bg-gold" : "bg-border"}`}
              />
            )}
          </div>
        );
      })}
    </div>
  );
}

/* ============== FLOW: EVENTO ============== */
function FlowEvento({ onSwitchToTrabalho }: { onSwitchToTrabalho: () => void }) {
  const [step, setStep] = useState(0);
  const [data, setData] = useState({
    nome: "",
    email: "",
    telefone: "",
    whatsapp: "",
    sameWhats: true,
  });
  const [coupon, setCoupon] = useState({ code: "", state: "idle" as "idle" | "loading" | "valid" | "invalid", discount: 0 });
  const [method, setMethod] = useState<Method>("pix");
  const [showCombineBanner, setShowCombineBanner] = useState(true);

  const total = useMemo(
    () => Math.max(0, precos.evento - coupon.discount),
    [coupon.discount]
  );

  function applyCoupon() {
    if (!coupon.code) return;
    setCoupon((c) => ({ ...c, state: "loading" }));
    setTimeout(() => {
      const pct = COUPONS[coupon.code.toUpperCase()];
      if (pct) {
        setCoupon((c) => ({
          ...c,
          state: "valid",
          discount: Math.round(precos.evento * (pct / 100)),
        }));
      } else {
        setCoupon((c) => ({ ...c, state: "invalid", discount: 0 }));
      }
    }, 900);
  }

  return (
    <div>
      <Stepper steps={["Dados Pessoais", "Pagamento", "Confirmação"]} current={step} />

      <AnimatePresence mode="wait">
        {step === 0 && (
          <motion.div key="s1" variants={fade} initial="hidden" animate="visible" exit="exit">
            <div className="grid gap-8 md:grid-cols-[1fr_320px]">
              <div className="space-y-5">
                <DadosForm value={data} onChange={setData} />
                <CouponField
                  state={coupon.state}
                  value={coupon.code}
                  onChange={(v) => setCoupon((c) => ({ ...c, code: v, state: "idle" }))}
                  onApply={applyCoupon}
                />
              </div>
              <OrderSummary
                lines={[{ label: "Inscrição no Evento", value: precos.evento }]}
                discount={coupon.state === "valid" ? coupon.discount : 0}
                total={total}
              />
            </div>

            <AnimatePresence>
              {showCombineBanner && (
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, height: 0, marginTop: 0 }}
                  className="mt-6 flex flex-wrap items-center gap-4 rounded-lg border border-gold bg-[#fff8f8] px-4 py-3"
                >
                  <Info className="h-5 w-5 shrink-0 text-gold" />
                  <p className="flex-1 font-body text-sm text-foreground">
                    Deseja também submeter um trabalho acadêmico?
                  </p>
                  <button
                    onClick={onSwitchToTrabalho}
                    className="rounded-md border border-primary px-3 py-1.5 font-body text-xs font-semibold text-primary hover:bg-primary hover:text-white"
                  >
                    Sim, adicionar submissão
                  </button>
                  <button
                    onClick={() => setShowCombineBanner(false)}
                    className="font-body text-xs font-semibold text-muted-foreground hover:text-foreground"
                  >
                    Não, continuar
                  </button>
                </motion.div>
              )}
            </AnimatePresence>

            <PrimaryButton onClick={() => setStep(1)} disabled={!data.nome || !data.email}>
              Continuar para Pagamento
            </PrimaryButton>
          </motion.div>
        )}

        {step === 1 && (
          <motion.div key="s2" variants={fade} initial="hidden" animate="visible" exit="exit">
            <PaymentStep
              method={method}
              setMethod={setMethod}
              total={total}
              onBack={() => setStep(0)}
              onConfirm={() => setStep(2)}
            />
          </motion.div>
        )}

        {step === 2 && (
          <motion.div key="s3" variants={fade} initial="hidden" animate="visible" exit="exit">
            <Confirmacao email={data.email} onReset={() => setStep(0)} />
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

/* ============== FLOW: TRABALHO ============== */
function FlowTrabalho() {
  const [step, setStep] = useState(0);
  const [data, setData] = useState({
    nome: "",
    email: "",
    telefone: "",
    whatsapp: "",
    sameWhats: true,
  });
  const [coauthors, setCoauthors] = useState<string[]>([]);
  const [work, setWork] = useState({ titulo: "", resumo: "", categoria: "" });
  const [file, setFile] = useState<File | null>(null);
  const [method, setMethod] = useState<Method>("pix");

  return (
    <div>
      <Stepper steps={["Dados", "Trabalho", "Pagamento", "Confirmação"]} current={step} />

      <AnimatePresence mode="wait">
        {step === 0 && (
          <motion.div key="t1" variants={fade} initial="hidden" animate="visible" exit="exit" className="space-y-6">
            <DadosForm value={data} onChange={setData} />

            <div>
              <div className="mb-3 flex items-center justify-between">
                <h4 className="font-display text-base font-bold text-foreground">Coautores</h4>
                <button
                  onClick={() => setCoauthors((c) => [...c, ""])}
                  className="inline-flex items-center gap-1.5 rounded-md border border-primary px-3 py-1.5 font-body text-xs font-semibold text-primary hover:bg-primary hover:text-white"
                >
                  <Plus className="h-3.5 w-3.5" /> Adicionar
                </button>
              </div>
              <AnimatePresence initial={false}>
                {coauthors.map((c, i) => (
                  <motion.div
                    key={i}
                    initial={{ opacity: 0, y: -8, height: 0 }}
                    animate={{ opacity: 1, y: 0, height: "auto" }}
                    exit={{ opacity: 0, y: -8, height: 0 }}
                    className="mb-2 flex items-center gap-2"
                  >
                    <input
                      value={c}
                      onChange={(e) => {
                        const next = [...coauthors];
                        next[i] = e.target.value;
                        setCoauthors(next);
                      }}
                      placeholder="Nome do coautor"
                      className="flex-1 rounded-md border border-input bg-surface px-3 py-2 text-sm outline-none focus:border-primary focus:ring-2 focus:ring-primary/20"
                    />
                    <button
                      onClick={() => setCoauthors(coauthors.filter((_, k) => k !== i))}
                      className="text-muted-foreground hover:text-destructive"
                      aria-label="Remover"
                    >
                      <X className="h-4 w-4" />
                    </button>
                  </motion.div>
                ))}
              </AnimatePresence>
              {coauthors.length === 0 && (
                <p className="font-body text-xs text-muted-foreground">Nenhum coautor adicionado.</p>
              )}
            </div>

            <PrimaryButton disabled={!data.nome || !data.email} onClick={() => setStep(1)}>
              Continuar
            </PrimaryButton>
          </motion.div>
        )}

        {step === 1 && (
          <motion.div key="t2" variants={fade} initial="hidden" animate="visible" exit="exit" className="space-y-5">
            <Field label="Título do Trabalho">
              <input
                value={work.titulo}
                onChange={(e) => setWork({ ...work, titulo: e.target.value })}
                className="w-full rounded-md border border-input bg-surface px-3 py-2 text-sm outline-none focus:border-primary focus:ring-2 focus:ring-primary/20"
              />
            </Field>
            <Field label={`Resumo (${work.resumo.length}/500)`}>
              <textarea
                value={work.resumo}
                onChange={(e) => setWork({ ...work, resumo: e.target.value.slice(0, 500) })}
                rows={4}
                className="w-full rounded-md border border-input bg-surface px-3 py-2 text-sm outline-none focus:border-primary focus:ring-2 focus:ring-primary/20"
              />
            </Field>
            <Field label="Categoria">
              <select
                value={work.categoria}
                onChange={(e) => setWork({ ...work, categoria: e.target.value })}
                className="w-full rounded-md border border-input bg-surface px-3 py-2 text-sm outline-none focus:border-primary focus:ring-2 focus:ring-primary/20"
              >
                <option value="">Selecione...</option>
                <option>Pesquisa Científica</option>
                <option>Relato de Caso</option>
                <option>Revisão de Literatura</option>
                <option>Painel Acadêmico</option>
              </select>
            </Field>

            <FileUpload file={file} onChange={setFile} />

            <Accordion title="Instruções para Formatação">
              <p>
                Lorem ipsum — instruções a definir pelo cliente. Formato A4, fonte Arial 12,
                espaçamento 1.5, máximo 8 páginas. Inclua referências em ABNT.
              </p>
            </Accordion>

            <PrimaryButton
              disabled={!work.titulo || !work.categoria}
              onClick={() => setStep(2)}
            >
              Continuar para Pagamento
            </PrimaryButton>
          </motion.div>
        )}

        {step === 2 && (
          <motion.div key="t3" variants={fade} initial="hidden" animate="visible" exit="exit">
            <div className="mb-4 flex items-start gap-3 rounded-lg border border-gold/50 bg-gold/10 px-4 py-3">
              <Info className="h-5 w-5 shrink-0 text-gold" />
              <p className="font-body text-sm text-foreground">
                Não há descontos por cupom para submissão de trabalhos.
              </p>
            </div>
            <PaymentStep
              method={method}
              setMethod={setMethod}
              total={precos.trabalho}
              labelLinha="Submissão de Trabalho"
              onBack={() => setStep(1)}
              onConfirm={() => setStep(3)}
            />
          </motion.div>
        )}

        {step === 3 && (
          <motion.div key="t4" variants={fade} initial="hidden" animate="visible" exit="exit">
            <Confirmacao email={data.email} onReset={() => setStep(0)} />
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

/* ============== SUB-COMPONENTS ============== */

function DadosForm({
  value,
  onChange,
}: {
  value: { nome: string; email: string; telefone: string; whatsapp: string; sameWhats: boolean };
  onChange: (v: typeof value) => void;
}) {
  return (
    <div className="grid gap-4 sm:grid-cols-2">
      <Field label="Nome Completo">
        <input
          value={value.nome}
          onChange={(e) => onChange({ ...value, nome: e.target.value })}
          className="w-full rounded-md border border-input bg-surface px-3 py-2 text-sm outline-none focus:border-primary focus:ring-2 focus:ring-primary/20"
        />
      </Field>
      <Field label="E-mail">
        <input
          type="email"
          value={value.email}
          onChange={(e) => onChange({ ...value, email: e.target.value })}
          className="w-full rounded-md border border-input bg-surface px-3 py-2 text-sm outline-none focus:border-primary focus:ring-2 focus:ring-primary/20"
        />
      </Field>
      <Field label="Telefone">
        <input
          value={value.telefone}
          onChange={(e) =>
            onChange({
              ...value,
              telefone: e.target.value,
              whatsapp: value.sameWhats ? e.target.value : value.whatsapp,
            })
          }
          className="w-full rounded-md border border-input bg-surface px-3 py-2 text-sm outline-none focus:border-primary focus:ring-2 focus:ring-primary/20"
        />
      </Field>
      <div>
        <Field label="WhatsApp">
          <input
            value={value.sameWhats ? value.telefone : value.whatsapp}
            disabled={value.sameWhats}
            onChange={(e) => onChange({ ...value, whatsapp: e.target.value })}
            className="w-full rounded-md border border-input bg-surface px-3 py-2 text-sm outline-none focus:border-primary focus:ring-2 focus:ring-primary/20 disabled:bg-background"
          />
        </Field>
        <label className="mt-2 flex items-center gap-2 font-body text-xs text-muted-foreground">
          <input
            type="checkbox"
            checked={value.sameWhats}
            onChange={(e) => onChange({ ...value, sameWhats: e.target.checked })}
            className="h-3.5 w-3.5 accent-primary"
          />
          Mesmo número do telefone
        </label>
      </div>
    </div>
  );
}

function CouponField({
  state,
  value,
  onChange,
  onApply,
}: {
  state: "idle" | "loading" | "valid" | "invalid";
  value: string;
  onChange: (v: string) => void;
  onApply: () => void;
}) {
  return (
    <div>
      <label className="mb-1 block font-body text-xs font-semibold text-foreground">
        Cupom de Desconto
      </label>
      <div className="flex gap-2">
        <input
          value={value}
          onChange={(e) => onChange(e.target.value)}
          placeholder="Digite seu cupom"
          className="flex-1 rounded-md border border-input bg-surface px-3 py-2 text-sm outline-none focus:border-primary focus:ring-2 focus:ring-primary/20"
        />
        <button
          onClick={onApply}
          disabled={state === "loading" || !value}
          className="rounded-md bg-primary px-5 font-body text-sm font-semibold text-white disabled:opacity-50"
        >
          {state === "loading" ? <Loader2 className="h-4 w-4 animate-spin" /> : "Aplicar"}
        </button>
      </div>
      {state === "valid" && (
        <p className="mt-2 inline-flex items-center gap-1.5 rounded-full bg-green-100 px-2 py-0.5 font-body text-xs font-semibold text-green-700">
          <Check className="h-3.5 w-3.5" /> Desconto aplicado
        </p>
      )}
      {state === "invalid" && (
        <p className="mt-2 inline-flex items-center gap-1.5 font-body text-xs font-semibold text-destructive">
          <X className="h-3.5 w-3.5" /> Cupom inválido ou já utilizado
        </p>
      )}
      <p className="mt-1 font-body text-[11px] text-muted-foreground">
        Tente <code>COBEO10</code> ou <code>ALUNO20</code>.
      </p>
    </div>
  );
}

function OrderSummary({
  lines,
  discount,
  total,
}: {
  lines: { label: string; value: number }[];
  discount: number;
  total: number;
}) {
  return (
    <aside className="self-start rounded-xl border border-border bg-background p-6 md:sticky md:top-24">
      <h4 className="font-display text-lg font-bold text-foreground">Resumo do Pedido</h4>
      <ul className="mt-4 space-y-2 font-body text-sm text-muted-foreground">
        {lines.map((l) => (
          <li key={l.label} className="flex items-baseline justify-between gap-2">
            <span>{l.label}</span>
            <span className="text-foreground">R$ {l.value}</span>
          </li>
        ))}
        {discount > 0 && (
          <li className="flex items-baseline justify-between gap-2 text-green-700">
            <span>Desconto</span>
            <span>- R$ {discount}</span>
          </li>
        )}
      </ul>
      <div className="my-4 h-px bg-border" />
      <div className="flex items-baseline justify-between">
        <span className="font-body text-sm text-muted-foreground">Total</span>
        <span className="font-display text-2xl font-extrabold text-primary">R$ {total}</span>
      </div>
      <p className="mt-3 font-body text-[11px] text-muted-foreground">
        Após confirmação do pagamento você receberá um e-mail.
      </p>
    </aside>
  );
}

function PrimaryButton({
  children,
  onClick,
  disabled,
}: {
  children: React.ReactNode;
  onClick: () => void;
  disabled?: boolean;
}) {
  return (
    <button
      onClick={onClick}
      disabled={disabled}
      className="mt-8 w-full rounded-md bg-primary px-6 py-4 font-body text-sm font-semibold text-white transition-colors hover:bg-[#8B1515] disabled:opacity-50"
    >
      {children}
    </button>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div>
      <label className="mb-1 block font-body text-xs font-semibold text-foreground">{label}</label>
      {children}
    </div>
  );
}

/* ============== PAYMENT ============== */
function PaymentStep({
  method,
  setMethod,
  total,
  labelLinha = "Inscrição no Evento",
  onBack,
  onConfirm,
}: {
  method: Method;
  setMethod: (m: Method) => void;
  total: number;
  labelLinha?: string;
  onBack: () => void;
  onConfirm: () => void;
}) {
  return (
    <div>
      <div className="mb-6 grid gap-3 sm:grid-cols-3">
        <PayCard active={method === "pix"} onClick={() => setMethod("pix")} icon={<QrCode />} title="PIX" sub="Aprovação imediata" />
        <PayCard active={method === "debito"} onClick={() => setMethod("debito")} icon={<Banknote />} title="Débito" sub="Aprovação imediata" />
        <PayCard active={method === "credito"} onClick={() => setMethod("credito")} icon={<CreditCard />} title="Crédito" sub="Parcelamento disponível" />
      </div>

      <div className="mb-4 flex items-baseline justify-between rounded-lg border border-border bg-background px-4 py-3">
        <span className="font-body text-sm text-muted-foreground">{labelLinha}</span>
        <span className="font-display text-xl font-extrabold text-primary">R$ {total}</span>
      </div>

      <AnimatePresence mode="wait">
        {method === "pix" && (
          <motion.div key="pix" variants={fade} initial="hidden" animate="visible" exit="exit">
            <PixPanel />
          </motion.div>
        )}
        {method !== "pix" && (
          <motion.div key="card" variants={fade} initial="hidden" animate="visible" exit="exit">
            <CardPanel />
          </motion.div>
        )}
      </AnimatePresence>

      <div className="mt-6 flex gap-3">
        <button
          onClick={onBack}
          className="rounded-md border border-border px-6 py-3 font-body text-sm font-semibold text-muted-foreground hover:text-foreground"
        >
          Voltar
        </button>
        <button
          onClick={onConfirm}
          className="flex-1 rounded-md bg-primary px-6 py-3 font-body text-sm font-semibold text-white hover:bg-[#8B1515]"
        >
          Confirmar Pagamento
        </button>
      </div>
    </div>
  );
}

function PayCard({
  active,
  onClick,
  icon,
  title,
  sub,
}: {
  active: boolean;
  onClick: () => void;
  icon: React.ReactNode;
  title: string;
  sub: string;
}) {
  return (
    <button
      onClick={onClick}
      className={`relative rounded-xl border-2 px-5 py-4 text-left transition-all ${
        active ? "border-primary bg-[#fff8f8]" : "border-border bg-surface hover:border-primary/50"
      }`}
    >
      {active && (
        <span className="absolute right-3 top-3 flex h-5 w-5 items-center justify-center rounded-full bg-primary">
          <Check className="h-3 w-3 text-white" />
        </span>
      )}
      <div className="text-primary [&_svg]:h-5 [&_svg]:w-5">{icon}</div>
      <div className="mt-2 font-display text-sm font-bold text-foreground">{title}</div>
      <div className="font-body text-[11px] text-muted-foreground">{sub}</div>
    </button>
  );
}

function PixPanel() {
  const [secs, setSecs] = useState(899);
  useEffect(() => {
    const id = setInterval(() => setSecs((s) => (s > 0 ? s - 1 : s)), 1000);
    return () => clearInterval(id);
  }, []);


  const mm = String(Math.floor(secs / 60)).padStart(2, "0");
  const ss = String(secs % 60).padStart(2, "0");
  const key = "00020126360014BR.GOV.BCB.PIX0114cobeo@unifafibe5204000053039865802BR";

  return (
    <div className="grid items-center gap-6 rounded-xl border border-border bg-background p-6 md:grid-cols-[200px_1fr]">
      <div className="flex h-[200px] w-[200px] items-center justify-center rounded-lg bg-white">
        <QrCode className="h-24 w-24 text-primary" />
      </div>
      <div>
        <p className="font-body text-xs font-semibold uppercase tracking-wider text-muted-foreground">
          Chave PIX Copia e Cola
        </p>
        <div className="mt-1 flex items-center gap-2">
          <input
            readOnly
            value={key}
            className="flex-1 rounded-md border border-input bg-surface px-3 py-2 font-mono text-xs"
          />
          <button
            onClick={() => navigator.clipboard?.writeText(key)}
            className="rounded-md bg-primary p-2 text-white"
            aria-label="Copiar"
          >
            <Copy className="h-4 w-4" />
          </button>
        </div>
        <div className="mt-4 flex items-center justify-between rounded-md bg-[#fff8f8] px-4 py-3">
          <span className="font-body text-sm text-muted-foreground">Expira em</span>
          <span className="font-mono text-xl font-bold text-primary">{mm}:{ss}</span>
        </div>
        <p className="mt-3 inline-flex items-center gap-2 font-body text-xs text-muted-foreground">
          <span className="relative flex h-2 w-2">
            <span className="absolute inset-0 animate-ping rounded-full bg-primary opacity-60" />
            <span className="relative h-2 w-2 rounded-full bg-primary" />
          </span>
          Aguardando confirmação do pagamento...
        </p>
      </div>
    </div>
  );
}

function CardPanel() {
  const [card, setCard] = useState({ number: "", name: "", expiry: "", cvv: "" });
  const masked = card.number.replace(/\D/g, "").slice(0, 16).replace(/(.{4})/g, "$1 ").trim();
  return (
    <div className="grid gap-6 md:grid-cols-[280px_1fr]">
      <div
        className="flex h-[160px] w-full max-w-[280px] flex-col justify-between rounded-2xl p-5 text-white shadow-lg"
        style={{
          background: "linear-gradient(135deg, #731111 0%, #4a0a0a 100%)",
        }}
      >
        <CreditCard className="h-7 w-7 text-gold" />
        <div>
          <div className="font-mono text-lg tracking-wider">
            {masked || "0000 0000 0000 0000"}
          </div>
          <div className="mt-3 flex justify-between font-mono text-xs uppercase">
            <span>{card.name || "Nome no Cartão"}</span>
            <span>{card.expiry || "MM/AA"}</span>
          </div>
        </div>
      </div>

      <div className="space-y-3">
        <input
          value={masked}
          onChange={(e) => setCard({ ...card, number: e.target.value })}
          placeholder="Número do Cartão"
          className="w-full rounded-md border border-input bg-surface px-3 py-2 font-mono text-sm outline-none focus:border-primary focus:ring-2 focus:ring-primary/20"
        />
        <input
          value={card.name}
          onChange={(e) => setCard({ ...card, name: e.target.value.toUpperCase() })}
          placeholder="Nome no Cartão"
          className="w-full rounded-md border border-input bg-surface px-3 py-2 text-sm uppercase outline-none focus:border-primary focus:ring-2 focus:ring-primary/20"
        />
        <div className="grid grid-cols-2 gap-3">
          <input
            value={card.expiry}
            onChange={(e) => setCard({ ...card, expiry: e.target.value.slice(0, 5) })}
            placeholder="MM/AA"
            className="rounded-md border border-input bg-surface px-3 py-2 font-mono text-sm outline-none focus:border-primary focus:ring-2 focus:ring-primary/20"
          />
          <input
            value={card.cvv}
            onChange={(e) => setCard({ ...card, cvv: e.target.value.slice(0, 4) })}
            placeholder="CVV"
            className="rounded-md border border-input bg-surface px-3 py-2 font-mono text-sm outline-none focus:border-primary focus:ring-2 focus:ring-primary/20"
          />
        </div>
      </div>
    </div>
  );
}

/* ============== CONFIRMATION ============== */
function Confirmacao({ email, onReset }: { email: string; onReset: () => void }) {
  return (
    <div className="py-6 text-center">
      <motion.div
        initial={{ scale: 0, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ duration: 0.5, ease: "easeOut" }}
        className="mx-auto flex h-20 w-20 items-center justify-center rounded-full bg-gold"
      >
        <Check className="h-10 w-10 text-primary" strokeWidth={3} />
      </motion.div>
      <h3 className="mt-6 font-display text-3xl font-extrabold text-foreground">
        Inscrição Confirmada!
      </h3>
      <p className="mt-2 font-body text-sm text-muted-foreground">
        Um e-mail de confirmação foi enviado para{" "}
        <span className="font-semibold text-foreground">{email || "seu endereço"}</span>.
      </p>
      <div className="mx-auto mt-8 max-w-md rounded-xl border border-border bg-background p-5 text-left">
        <p className="font-body text-xs font-semibold uppercase tracking-wider text-muted-foreground">
          Protocolo
        </p>
        <p className="mt-1 font-mono text-base font-bold text-primary">
          COBEO-{Math.random().toString(36).slice(2, 8).toUpperCase()}
        </p>
      </div>
      <div className="mt-8 flex flex-wrap justify-center gap-3">
        <button
          onClick={onReset}
          className="rounded-md border border-border px-6 py-3 font-body text-sm font-semibold text-foreground hover:bg-background"
        >
          Página Inicial
        </button>
        <a
          href="#inscricoes"
          className="rounded-md bg-primary px-6 py-3 font-body text-sm font-semibold text-white hover:bg-[#8B1515]"
        >
          Submeter Trabalho
        </a>
      </div>
    </div>
  );
}

/* ============== FILE UPLOAD ============== */
function FileUpload({ file, onChange }: { file: File | null; onChange: (f: File | null) => void }) {
  const [over, setOver] = useState(false);
  function onDrop(e: DragEvent<HTMLLabelElement>) {
    e.preventDefault();
    setOver(false);
    const f = e.dataTransfer.files?.[0];
    if (f) onChange(f);
  }
  function onPick(e: ChangeEvent<HTMLInputElement>) {
    const f = e.target.files?.[0];
    if (f) onChange(f);
  }
  return (
    <div>
      <label
        onDragOver={(e) => {
          e.preventDefault();
          setOver(true);
        }}
        onDragLeave={() => setOver(false)}
        onDrop={onDrop}
        className={`flex cursor-pointer flex-col items-center gap-2 rounded-xl border-2 border-dashed px-6 py-10 text-center transition-colors ${
          over ? "border-primary bg-[#fff8f8]" : "border-border bg-background"
        }`}
      >
        <Upload className="h-10 w-10 text-secondary" />
        <p className="font-body text-base font-medium text-foreground">
          Arraste seu arquivo aqui
        </p>
        <p className="font-body text-sm text-primary underline">ou clique para selecionar</p>
        <p className="font-body text-xs text-muted-foreground">PDF, DOC, DOCX, PPT, PPTX</p>
        <input type="file" hidden onChange={onPick} accept=".pdf,.doc,.docx,.ppt,.pptx" />
      </label>
      {file && (
        <div className="mt-3 inline-flex items-center gap-3 rounded-md border border-border bg-background px-3 py-2">
          <FileText className="h-4 w-4 text-primary" />
          <span className="font-body text-sm text-foreground">{file.name}</span>
          <span className="font-body text-xs text-muted-foreground">
            {(file.size / 1024).toFixed(0)} KB
          </span>
          <button
            onClick={() => onChange(null)}
            className="text-muted-foreground hover:text-destructive"
            aria-label="Remover"
          >
            <X className="h-4 w-4" />
          </button>
        </div>
      )}
    </div>
  );
}

/* ============== ACCORDION ============== */
function Accordion({ title, children }: { title: string; children: React.ReactNode }) {
  const [open, setOpen] = useState(false);
  return (
    <div className="rounded-lg border border-border bg-background">
      <button
        onClick={() => setOpen(!open)}
        className="flex w-full items-center justify-between px-4 py-3 text-left font-body text-sm font-semibold text-foreground"
      >
        {title}
        <ChevronDown
          className={`h-4 w-4 text-muted-foreground transition-transform ${open ? "rotate-180" : ""}`}
        />
      </button>
      <AnimatePresence initial={false}>
        {open && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.25 }}
            className="overflow-hidden"
          >
            <div className="px-4 pb-4 font-body text-sm text-muted-foreground">{children}</div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
