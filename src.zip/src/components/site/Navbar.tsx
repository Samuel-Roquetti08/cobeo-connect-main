import { useEffect, useState } from "react";
import { Menu, X } from "lucide-react";
import { Link } from "@tanstack/react-router";
import { UnifafibeLogo, OdontoSeal } from "./logos";

const links = [
  { href: "#sobre", label: "Sobre" },
  { href: "#palestrantes", label: "Palestrantes" },
  { href: "#programacao", label: "Programação" },
  { href: "#inscricoes", label: "Inscrições" },
  { href: "#contato", label: "Contato" },
];

export function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 16);
    onScroll();
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <header
      className={`sticky top-0 z-50 bg-primary text-primary-foreground transition-shadow ${
        scrolled ? "shadow-[0_4px_24px_rgba(0,0,0,0.15)]" : ""
      }`}
    >
      <div className="mx-auto flex h-[72px] max-w-7xl items-center justify-between gap-4 px-4 sm:px-6">
        <a href="#top" className="flex items-center gap-4">
          <OdontoSeal className="h-10" />
          <UnifafibeLogo className="h-9" />
        </a>

        <nav className="hidden items-center gap-7 md:flex">
          {links.map((l) => (
            <a
              key={l.href}
              href={l.href}
              className="nav-underline font-body text-sm font-medium text-white/90"
            >
              {l.label}
            </a>
          ))}
          <Link
            to="/admin"
            className="rounded-md border border-white px-4 py-2 font-body text-xs font-semibold uppercase tracking-wider text-white transition-colors hover:bg-white hover:text-primary"
          >
            Área Admin
          </Link>
        </nav>

        <button onClick={() => setOpen(!open)} className="md:hidden" aria-label="Menu">
          {open ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
        </button>
      </div>

      {open && (
        <div className="fixed inset-0 top-[72px] z-40 bg-primary px-6 py-10 md:hidden">
          <nav className="flex flex-col gap-5">
            {links.map((l) => (
              <a
                key={l.href}
                href={l.href}
                onClick={() => setOpen(false)}
                className="font-display text-2xl font-bold text-white"
              >
                {l.label}
              </a>
            ))}
            <Link
              to="/admin"
              onClick={() => setOpen(false)}
              className="mt-4 inline-block rounded-md border border-white px-5 py-3 text-center font-body text-sm font-semibold uppercase text-white"
            >
              Área Admin
            </Link>
          </nav>
        </div>
      )}
    </header>
  );
}
