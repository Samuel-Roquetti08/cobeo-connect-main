import unifafibeAsset from "@/assets/unifafibe-logo.jpg.asset.json";
import odontoAsset from "@/assets/odontologia-seal.jpg.asset.json";
import cobeoAsset from "@/assets/cobeo-illustration.jpg.asset.json";

export const UNIFAFIBE_LOGO = unifafibeAsset.url;
export const ODONTO_SEAL = odontoAsset.url;
export const COBEO_ILLUSTRATION = cobeoAsset.url;

export function UnifafibeLogo({ className = "h-10" }: { className?: string }) {
  return (
    <img
      src={UNIFAFIBE_LOGO}
      alt="UNIFAFIBE — Bebedouro/SP"
      className={`${className} w-auto object-contain`}
    />
  );
}

export function OdontoSeal({ className = "h-10" }: { className?: string }) {
  return (
    <img
      src={ODONTO_SEAL}
      alt="Odontologia UNIFAFIBE"
      className={`${className} w-auto object-contain rounded-full`}
    />
  );
}
