import { createFileRoute, useNavigate, Link } from "@tanstack/react-router";
import { useEffect, useState, type FormEvent } from "react";
import { Lock, Mail } from "lucide-react";
import { useAdminAuth } from "@/lib/adminAuth";

export const Route = createFileRoute("/admin/login")({
  head: () => ({ meta: [{ title: "Admin · II COBEO" }] }),
  component: AdminLogin,
});

function AdminLogin() {
  const navigate = useNavigate();
  const { login, user, ready } = useAdminAuth();
  const [err, setErr] = useState("");

  useEffect(() => {
    if (ready && user) navigate({ to: "/admin/dashboard" });
  }, [ready, user, navigate]);

  function onSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const email = String(fd.get("email") || "");
    const pass = String(fd.get("pass") || "");
    if (login(email, pass)) navigate({ to: "/admin/dashboard" });
    else setErr("Credenciais inválidas.");
  }

  return (
    <div
      className="flex min-h-screen items-center justify-center bg-[#1a0505] px-4"
      style={{ fontFamily: "Poppins, system-ui, sans-serif" }}
    >
      <form
        onSubmit={onSubmit}
        className="w-full max-w-sm rounded-xl border border-white/10 bg-[#0f0303] p-8 shadow-2xl"
      >
        <div className="mb-6 text-center">
          <div className="mx-auto mb-3 grid h-12 w-12 place-items-center rounded-md bg-[#731111] font-bold text-white">
            II
          </div>
          <h1 className="text-xl font-semibold text-white">II COBEO · Admin</h1>
          <p className="mt-1 text-xs text-white/50">Acesso restrito à organização do evento.</p>
        </div>

        <div className="space-y-4">
          <div>
            <label className="mb-1 block text-[11px] font-medium text-white/60">E-mail</label>
            <div className="relative">
              <Mail className="absolute left-3 top-2.5 h-4 w-4 text-white/30" />
              <input
                name="email"
                type="email"
                required
                defaultValue="admin@cobeo.com.br"
                className="w-full rounded-md border border-white/10 bg-white/5 px-9 py-2 text-sm text-white outline-none focus:border-[#C9A84C]"
              />
            </div>
          </div>
          <div>
            <label className="mb-1 block text-[11px] font-medium text-white/60">Senha</label>
            <div className="relative">
              <Lock className="absolute left-3 top-2.5 h-4 w-4 text-white/30" />
              <input
                name="pass"
                type="password"
                required
                className="w-full rounded-md border border-white/10 bg-white/5 px-9 py-2 text-sm text-white outline-none focus:border-[#C9A84C]"
              />
            </div>
          </div>
        </div>

        {err && (
          <div className="mt-4 rounded-md border border-red-500/30 bg-red-500/10 px-3 py-2 text-xs text-red-300">
            {err}
          </div>
        )}

        <button
          type="submit"
          className="mt-6 w-full rounded-md bg-[#731111] px-4 py-2.5 text-sm font-semibold text-white transition-colors hover:bg-[#8a1515]"
        >
          Entrar no Painel
        </button>

        <div className="mt-4 flex items-center justify-between text-[11px] text-white/40">
          <span>
            Demo: <code className="text-white/70">admin@cobeo.com.br</code> / <code className="text-white/70">cobeo2025</code>
          </span>
          <Link to="/" className="hover:text-white/80">← Site</Link>
        </div>
      </form>
    </div>
  );
}
